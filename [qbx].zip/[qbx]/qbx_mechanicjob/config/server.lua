return {
    authorizedIds = {
        'citizenid',
    }
}